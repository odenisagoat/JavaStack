package com.example.dailydiaryjavastack;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class Password extends AppCompatActivity {

    String correctpass = "1234";
    int passlength = 4;
    int amount = 0;
    TextView firstnum,secondnum,thirdnum,fourthnum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password);

    }

    StringBuilder password = new StringBuilder();

    public void PassCorI(StringBuilder pass) {
        if (pass.length() == passlength) {
            if (pass.toString().equals(correctpass)) {
                Intent login = new Intent(getApplicationContext(), ProfilePage.class);
                startActivity(login);
                finish();
            } else {
                Toast.makeText(this, "Password is Incorrect", Toast.LENGTH_SHORT).show();
                password = new StringBuilder();
            }
        }

    }

}