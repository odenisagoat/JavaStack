package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import com.hanks.passcodeview.PasscodeView;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;


public class Password extends AppCompatActivity {
    PasscodeView passcodeView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password);
        passcodeView=findViewById(R.id.password);
        passcodeView.setPasscodeLength(4)
                .setLocalPasscode("2580")
                .setListener(new PasscodeView.PasscodeViewListener() {
                    @Override
                    public void onSuccess(String number) {
                        Toast.makeText(getApplicationContext(), "Correct Password", Toast.LENGTH_SHORT).show();
                        Intent pass=new Intent(Password.this, StartPage.class);
                        startActivity(pass);
                    }

                    @Override
                    public void onFail() {
                        Toast.makeText(getApplicationContext(), "Incorrect Password", Toast.LENGTH_SHORT).show();

                    }
                });
    }



}