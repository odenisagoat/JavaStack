package com.example.myapplication;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

public class ProfilePage extends AppCompatActivity {
    private ImageButton addEntry;
    private ImageButton backProfile;
    ImageView profilePic;
    private final int gReq = 1;
    StorageReference storeRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_page);

        storeRef = FirebaseStorage.getInstance().getReference();

        StorageReference lastUploaded = storeRef.child("Picture.jpg");
        lastUploaded.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                Picasso.get().load(uri).into(profilePic);
            }
        });

        addEntry = findViewById(R.id.newEntryButton);
        addEntry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openNewEntry();
            }
        });

        backProfile = findViewById(R.id.backProfileButton);
        backProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                backProfilePage();
            }
        });

        profilePic = findViewById(R.id.profilePicture);
        profilePic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent gallery = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

                startActivityForResult(gallery, gReq);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode == gReq){
            if(resultCode == Activity.RESULT_OK);

            Uri profUri = data.getData();
            profilePic.setImageURI(profUri);

            upload(profUri);
        }
    }



    private void backProfilePage() {
        Intent backToPasswordIntent = new Intent(this, Password.class);
        startActivity(backToPasswordIntent);

    }

    public void openNewEntry() {
        Intent openNewEntryIntent = new Intent(this, NewEntry.class);
        startActivity(openNewEntryIntent);

    }

    private void upload(Uri uri) {

        StorageReference referenceFile = storeRef.child("Picture.jpg");
        referenceFile.putFile(uri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                referenceFile.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        Picasso.get().load(uri).into(profilePic);

                    }
                });

            }
        });

    }
}